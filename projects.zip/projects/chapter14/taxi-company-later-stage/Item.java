/**
 * An item in the city.
 * 
 * @author David J. Barnes and Michael Kölling
 * @version 2011.07.31
 */

public interface Item
{
    public Location getLocation();
}
